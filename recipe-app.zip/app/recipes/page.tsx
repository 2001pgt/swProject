"use client"

import { useState, useEffect } from "react"
import { useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Home, Clock, Users, Star } from "lucide-react"
import Link from "next/link"

// 샘플 레시피 데이터
const sampleRecipes = [
  {
    id: 1,
    name: "감자 볶음",
    image: "/placeholder.svg?height=200&width=300",
    cookTime: "15분",
    servings: 2,
    difficulty: "쉬움",
    rating: 4.5,
    ingredients: ["감자", "양파", "마늘"],
    description: "간단하고 맛있는 감자 볶음 요리",
  },
  {
    id: 2,
    name: "계란 볶음밥",
    image: "/placeholder.svg?height=200&width=300",
    cookTime: "10분",
    servings: 1,
    difficulty: "쉬움",
    rating: 4.8,
    ingredients: ["계란", "밥", "대파"],
    description: "간단한 한 끼 식사로 완벽한 볶음밥",
  },
  {
    id: 3,
    name: "토마토 파스타",
    image: "/placeholder.svg?height=200&width=300",
    cookTime: "20분",
    servings: 2,
    difficulty: "보통",
    rating: 4.3,
    ingredients: ["토마토", "마늘", "파스타면"],
    description: "신선한 토마토로 만든 이탈리안 파스타",
  },
]

export default function RecipesPage() {
  const searchParams = useSearchParams()
  const [recipes, setRecipes] = useState(sampleRecipes)
  const [ingredients, setIngredients] = useState("")

  useEffect(() => {
    const ingredientsParam = searchParams.get("ingredients")
    if (ingredientsParam) {
      setIngredients(ingredientsParam)
      // 실제로는 여기서 API 호출하여 레시피 검색
      // 지금은 샘플 데이터 사용
    }
  }, [searchParams])

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-50">
      {/* Header */}
      <header className="bg-white shadow-sm p-4">
        <div className="container mx-auto flex justify-between items-center">
          <Link href="/">
            <Button variant="ghost" size="sm">
              <Home className="h-4 w-4 mr-1" />
              홈으로
            </Button>
          </Link>
          <h1 className="text-xl font-bold text-gray-800">추천 레시피</h1>
          <div></div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* Search Info */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-800 mb-2">'{ingredients}' 재료로 만들 수 있는 요리</h2>
          <p className="text-gray-600">총 {recipes.length}개의 레시피를 찾았습니다</p>
        </div>

        {/* Recipe Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {recipes.map((recipe) => (
            <Link key={recipe.id} href={`/recipe/${recipe.id}`}>
              <Card className="hover:shadow-lg transition-shadow cursor-pointer h-full">
                <div className="aspect-video bg-gray-200 rounded-t-lg overflow-hidden">
                  <img
                    src={recipe.image || "/placeholder.svg"}
                    alt={recipe.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <CardTitle className="text-lg">{recipe.name}</CardTitle>
                    <div className="flex items-center text-sm text-yellow-600">
                      <Star className="h-4 w-4 fill-current mr-1" />
                      {recipe.rating}
                    </div>
                  </div>
                  <CardDescription>{recipe.description}</CardDescription>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="flex items-center justify-between text-sm text-gray-600 mb-3">
                    <div className="flex items-center">
                      <Clock className="h-4 w-4 mr-1" />
                      {recipe.cookTime}
                    </div>
                    <div className="flex items-center">
                      <Users className="h-4 w-4 mr-1" />
                      {recipe.servings}인분
                    </div>
                    <Badge variant="secondary">{recipe.difficulty}</Badge>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {recipe.ingredients.slice(0, 3).map((ingredient) => (
                      <Badge key={ingredient} variant="outline" className="text-xs">
                        {ingredient}
                      </Badge>
                    ))}
                    {recipe.ingredients.length > 3 && (
                      <Badge variant="outline" className="text-xs">
                        +{recipe.ingredients.length - 3}
                      </Badge>
                    )}
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </main>
    </div>
  )
}
