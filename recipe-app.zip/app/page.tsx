"use client"

import { useState } from "react"
import { Search, User, UserPlus, Home } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import Link from "next/link"
import { useRouter } from "next/navigation"

export default function HomePage() {
  const [ingredients, setIngredients] = useState("")
  const router = useRouter()

  const handleSearch = () => {
    if (ingredients.trim()) {
      router.push(`/recipes?ingredients=${encodeURIComponent(ingredients)}`)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-50">
      {/* Header */}
      <header className="flex justify-between items-center p-4 bg-white shadow-sm">
        <div className="flex items-center space-x-2">
          <Home className="h-6 w-6 text-orange-500" />
          <h1 className="text-xl font-bold text-gray-800">요리 레시피</h1>
        </div>
        <div className="flex space-x-2">
          <Link href="/login">
            <Button variant="ghost" size="sm">
              <User className="h-4 w-4 mr-1" />
              로그인
            </Button>
          </Link>
          <Link href="/signup">
            <Button variant="ghost" size="sm">
              <UserPlus className="h-4 w-4 mr-1" />
              회원가입
            </Button>
          </Link>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-12">
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="text-4xl font-bold text-gray-800 mb-4">
            냉장고 속 재료로 <br />
            <span className="text-orange-500">맛있는 요리</span>를 만들어보세요
          </h2>
          <p className="text-gray-600 mb-8 text-lg">가지고 있는 재료를 입력하면 만들 수 있는 요리를 추천해드려요</p>

          <Card className="p-6">
            <CardContent className="space-y-4">
              <div className="relative">
                <Input
                  type="text"
                  placeholder="재료를 입력하세요 (예: 양파, 당근, 감자)"
                  value={ingredients}
                  onChange={(e) => setIngredients(e.target.value)}
                  className="pr-12 h-12 text-lg"
                  onKeyPress={(e) => e.key === "Enter" && handleSearch()}
                />
                <Button onClick={handleSearch} className="absolute right-1 top-1 h-10" disabled={!ingredients.trim()}>
                  <Search className="h-4 w-4" />
                </Button>
              </div>
              <p className="text-sm text-gray-500">쉼표(,)로 구분하여 여러 재료를 입력할 수 있어요</p>
            </CardContent>
          </Card>

          {/* Popular Ingredients */}
          <div className="mt-8">
            <p className="text-gray-600 mb-4">인기 재료</p>
            <div className="flex flex-wrap justify-center gap-2">
              {["양파", "당근", "감자", "계란", "닭가슴살", "토마토", "마늘", "대파"].map((ingredient) => (
                <Button
                  key={ingredient}
                  variant="outline"
                  size="sm"
                  onClick={() => setIngredients((prev) => (prev ? `${prev}, ${ingredient}` : ingredient))}
                  className="rounded-full"
                >
                  {ingredient}
                </Button>
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
