"use client"

import { useState, useEffect } from "react"
import { useParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Home, Clock, Users, Star, Heart } from "lucide-react"
import Link from "next/link"

// 샘플 레시피 상세 데이터
const sampleRecipeDetail = {
  id: 1,
  name: "감자 볶음",
  image: "/placeholder.svg?height=400&width=600",
  cookTime: "15분",
  servings: 2,
  difficulty: "쉬움",
  rating: 4.5,
  description: "간단하고 맛있는 감자 볶음 요리입니다. 바삭하게 볶은 감자와 양파의 조화가 일품입니다.",
  ingredients: [
    { name: "감자", amount: "2개", essential: true },
    { name: "양파", amount: "1/2개", essential: true },
    { name: "마늘", amount: "2쪽", essential: true },
    { name: "식용유", amount: "2큰술", essential: false },
    { name: "소금", amount: "약간", essential: false },
    { name: "후추", amount: "약간", essential: false },
  ],
  instructions: [
    "감자는 껍질을 벗기고 한 입 크기로 썰어주세요.",
    "양파는 채 썰고, 마늘은 다져주세요.",
    "팬에 식용유를 두르고 중불에서 감자를 볶아주세요.",
    "감자가 반쯤 익으면 양파와 마늘을 넣고 함께 볶아주세요.",
    "감자가 노릇하게 익으면 소금과 후추로 간을 맞춰주세요.",
    "접시에 담아 뜨겁게 서빙하세요.",
  ],
  nutrition: {
    calories: 180,
    protein: 4,
    carbs: 35,
    fat: 3,
    fiber: 3,
  },
  tips: [
    "감자는 찬물에 담가 전분을 제거하면 더 바삭하게 볶을 수 있어요.",
    "중불에서 천천히 볶아야 겉은 바삭하고 속은 부드러워져요.",
  ],
}

export default function RecipeDetailPage() {
  const params = useParams()
  const [recipe, setRecipe] = useState(sampleRecipeDetail)
  const [isFavorite, setIsFavorite] = useState(false)

  useEffect(() => {
    // 실제로는 여기서 API 호출하여 레시피 상세 정보 가져오기
    // const recipeId = params.id
    // fetchRecipeDetail(recipeId)
  }, [params.id])

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-50">
      {/* Header */}
      <header className="bg-white shadow-sm p-4">
        <div className="container mx-auto flex justify-between items-center">
          <Link href="/recipes">
            <Button variant="ghost" size="sm">
              <Home className="h-4 w-4 mr-1" />
              목록으로
            </Button>
          </Link>
          <h1 className="text-xl font-bold text-gray-800">레시피 상세</h1>
          <Button variant="ghost" size="sm" onClick={() => setIsFavorite(!isFavorite)}>
            <Heart className={`h-4 w-4 ${isFavorite ? "fill-red-500 text-red-500" : ""}`} />
          </Button>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Recipe Header */}
        <div className="mb-8">
          <div className="aspect-video bg-gray-200 rounded-lg overflow-hidden mb-6">
            <img src={recipe.image || "/placeholder.svg"} alt={recipe.name} className="w-full h-full object-cover" />
          </div>

          <div className="flex justify-between items-start mb-4">
            <h1 className="text-3xl font-bold text-gray-800">{recipe.name}</h1>
            <div className="flex items-center text-yellow-600">
              <Star className="h-5 w-5 fill-current mr-1" />
              <span className="font-semibold">{recipe.rating}</span>
            </div>
          </div>

          <p className="text-gray-600 text-lg mb-4">{recipe.description}</p>

          <div className="flex items-center space-x-6 text-sm text-gray-600">
            <div className="flex items-center">
              <Clock className="h-4 w-4 mr-1" />
              {recipe.cookTime}
            </div>
            <div className="flex items-center">
              <Users className="h-4 w-4 mr-1" />
              {recipe.servings}인분
            </div>
            <Badge variant="secondary">{recipe.difficulty}</Badge>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Ingredients */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle>재료</CardTitle>
                <CardDescription>{recipe.servings}인분 기준</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {recipe.ingredients.map((ingredient, index) => (
                    <div key={index} className="flex justify-between items-center">
                      <span className={ingredient.essential ? "font-medium" : "text-gray-600"}>{ingredient.name}</span>
                      <span className="text-sm text-gray-500">{ingredient.amount}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Nutrition Info */}
            <Card className="mt-6">
              <CardHeader>
                <CardTitle>영양 정보</CardTitle>
                <CardDescription>1인분 기준</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>칼로리</span>
                    <span className="font-medium">{recipe.nutrition.calories}kcal</span>
                  </div>
                  <div className="flex justify-between">
                    <span>단백질</span>
                    <span className="font-medium">{recipe.nutrition.protein}g</span>
                  </div>
                  <div className="flex justify-between">
                    <span>탄수화물</span>
                    <span className="font-medium">{recipe.nutrition.carbs}g</span>
                  </div>
                  <div className="flex justify-between">
                    <span>지방</span>
                    <span className="font-medium">{recipe.nutrition.fat}g</span>
                  </div>
                  <div className="flex justify-between">
                    <span>식이섬유</span>
                    <span className="font-medium">{recipe.nutrition.fiber}g</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Instructions */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>조리 방법</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recipe.instructions.map((step, index) => (
                    <div key={index} className="flex space-x-4">
                      <div className="flex-shrink-0 w-8 h-8 bg-orange-500 text-white rounded-full flex items-center justify-center font-semibold text-sm">
                        {index + 1}
                      </div>
                      <p className="text-gray-700 leading-relaxed pt-1">{step}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Tips */}
            <Card className="mt-6">
              <CardHeader>
                <CardTitle>요리 팁</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {recipe.tips.map((tip, index) => (
                    <div key={index} className="flex space-x-3">
                      <div className="w-2 h-2 bg-orange-500 rounded-full mt-2 flex-shrink-0"></div>
                      <p className="text-gray-700">{tip}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}
